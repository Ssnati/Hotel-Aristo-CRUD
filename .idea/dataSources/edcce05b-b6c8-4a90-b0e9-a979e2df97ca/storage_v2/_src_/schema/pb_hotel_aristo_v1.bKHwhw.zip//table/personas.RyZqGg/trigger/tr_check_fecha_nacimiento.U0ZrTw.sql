create definer = root@localhost trigger tr_check_fecha_nacimiento
    before insert
    on personas
    for each row
BEGIN
   IF NEW.fecha_nacimiento >= DATE_SUB(CURDATE(), INTERVAL 18 YEAR) THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La persona debe ser mayor de edad.';
   END IF;
END;

