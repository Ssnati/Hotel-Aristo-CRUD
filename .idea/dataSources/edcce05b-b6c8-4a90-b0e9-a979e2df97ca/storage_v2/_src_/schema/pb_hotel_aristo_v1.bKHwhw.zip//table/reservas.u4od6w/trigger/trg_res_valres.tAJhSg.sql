create definer = root@localhost trigger trg_res_valres
    before insert
    on reservas
    for each row
BEGIN
   IF NEW.valor_reserva <= 0 THEN
      SIGNAL SQLSTATE '45000'
         SET MESSAGE_TEXT = 'El valor de la reserva debe ser mayor que cero.';
   END IF;
END;

