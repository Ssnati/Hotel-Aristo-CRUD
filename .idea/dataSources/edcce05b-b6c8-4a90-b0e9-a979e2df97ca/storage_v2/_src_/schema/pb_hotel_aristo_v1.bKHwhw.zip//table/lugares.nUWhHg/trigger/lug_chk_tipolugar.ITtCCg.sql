create definer = root@localhost trigger lug_chk_tipolugar
    before insert
    on lugares
    for each row
BEGIN
   IF NEW.tipo_lugar NOT IN ('PAI', 'CIU', 'OTR') THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El tipo de lugar debe ser PAI, CIU o OTR';
   END IF;
END;

