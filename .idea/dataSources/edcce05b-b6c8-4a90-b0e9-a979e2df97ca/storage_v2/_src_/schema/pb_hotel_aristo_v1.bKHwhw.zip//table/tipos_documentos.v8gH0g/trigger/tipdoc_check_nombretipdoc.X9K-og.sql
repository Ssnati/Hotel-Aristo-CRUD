create definer = root@localhost trigger tipdoc_check_nombretipdoc
    before insert
    on tipos_documentos
    for each row
BEGIN
    IF NEW.nombre_tipo_documento NOT IN ('CC', 'CE', 'PA', 'OT') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El nombre del tipo de documento no es válido';
    END IF;
END;

