create definer = root@localhost trigger tiposerv_check_precioserv
    before insert
    on tipos_servicio
    for each row
BEGIN
    IF NEW.precio_servicio <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El precio del servicio debe ser mayor a 0';
    END IF;
END;

